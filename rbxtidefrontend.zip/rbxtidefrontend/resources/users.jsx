export const ADMIN_ROLES = [
    'OWNER',
    'ADMIN',
    'DEV',
]

export const STAFF_ROLES = [
    ...ADMIN_ROLES,
    'MOD'
]